﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {

  $it4showingmsgsend = $con->customerContact($_POST);
}

?>

<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath . '/../classes/Contact.php');
$con = new Contact();
$fm = new Format ();
?>




<?php
 if (isset($_GET['shiftid'])) {
  $id   = $_GET['shiftid'];
 
  $shift = $con->MarkAsReadMesage($id);
}



if (isset($_GET['delproid'])) {
  $id = $_GET['delproid'];

  $delOrder = $con->delproductShifted($id);

 }



?>


   



        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
 <?php
     if (isset($shift)){
        echo $shift;
     }
     ?>
               <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>SL</th>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Phone</th>
							<th>Email</th>
							<th>Date</th>
							<th>Message</th>
							<th>Status</th>
							<th>5</th>
							<th> Action</th>
					   
						</tr>

					</thead>
					<tbody>
		    <?php

               $getCon = $con->GetAllUnreadMessagesForInBox();
               if ($getCon) {
              	$i = 0;
               	while ($result = $getCon->fetch_assoc()) {
              	 $i++;
            ?>
			<tr class="odd gradeX">
				<td><?php echo $i; ?></td>
				<td><?php echo $result['firstname']; ?></td>
				<td><?php echo $result['lastname']; ?></td>
				<td><?php echo $result['phone']; ?></td>
				<td><?php echo $result['email']; ?></td>
				<td><?php echo $fm->formatDate($result['date']);  ?></td>
				<td><?php echo $fm->textShorten($result['body'], 20); ?></td>



      <td><?php if ($result['status'] == '0'){ echo "Pending"; }else {echo "Pending";} ?>
}
 
<td><a href="?shiftid=<?php echo $result['id']; ?>">Move to seen</a> ||

 
 



 
	<a href="viewmsg.php?msgid=<?php echo $result['id']; ?>">View</a> ||
	<a href="replaymsg.php?replyid=<?php echo $result['id']; ?>">Reply</a> ||
 
</td>

			</tr>

	<?php 	} }  ?>

		
		</tbody>
	</table>
   </div>
</div>

<?php
  if (isset($_GET['delseenid'])) {
  $id = $_GET['delseenid']; 
  $delOrder = $con->DeleteReadMessage($id);
 }
?>


<div class="box round first grid">
    <h2>Replay</h2>
 <?php
     if (isset($delOrder)){
        echo $delOrder;
     }
     ?>
 
    <div class="block">        
  <table class="data display datatable" id="example">
					<thead>
						<tr>
							
							<th>SL</th>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Phone</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Status</th>
							<th>Action</th>
					
						    
						</tr>

					</thead>
					<tbody>  <?php

               $getCon = $con->GetReadMessagesForBelow();

               if ($getCon) {

              	$i = 0;

               	while ($result = $getCon->fetch_assoc()) {

              	 $i++;

              	
            ?>


						<tr class="odd gradeX">
							<td><?php echo $i; ?></td>
							<td><?php echo $result['firstname']; ?></td>
							<td><?php echo $result['lastname']; ?></td>
							<td><?php echo $result['phone']; ?></td>
							<td><?php echo $result['email']; ?></td>
							<td><?php echo $fm->textShorten($result['body'], 20); ?></td>
							<td><?php echo $fm->formatDate($result['date']);  ?></td>
							
  <td><?php if ($result['status'] == '0') {echo "Pending"; }else {echo "Read"; }?></td>
  <td><a onclick="return confirm('Are you sure to delete')" href="?delseenid=<?php echo $result['id'];?>">DELETE</a>
 </td>
</tr>			
<?php 	} }  ?>
</tbody>
	</table> 
	 </div>
       </div>
        </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>