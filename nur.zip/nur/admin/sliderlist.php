<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/Slider.php';  ?>
<?php include_once '../helpers/Format.php';?>

<?php
$sl = new Slider();
$fm = new Format();

?>



<?php
 if (isset($_GET['delsl'])) {
	 $id = $_GET['delsl'];
	 $delsl = $sl->delPorById($id);

}  

?>


<div class="grid_10">
    <div class="box round first grid">
        <h2>Slider List</h2>
        <div class="block">  

  <?php
         if (isset($delsl)) {
         	echo  $delsl;
         }
          ?>


            <table class="data display datatable" id="example">
			<thead>
				<tr>
				<th>Serial No</th>
					<th>Product Name</th>
					<th>Description</th>
					<th>Price</th>
					<th>Image</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
 
<?php 
           $sl =  new Slider();
           $getIm = $sl->getAllimage();
           if ($getIm) {
           	$i = 0;
          while ($result = $getIm->fetch_assoc() ) {
          	$i++;
         

           ?>


				<tr class="odd gradeX">
					<td><?php echo $i; ?></td>
					<td><?php echo $result['productName']; ?></td>
					<td><?php echo $result['body']; ?></td>
					<td><?php echo $result['price']; ?></td>
			<td><img src="<?php echo $result['image'];?>" height="40px; width=60px;"></td>			
				<td><a href="slideredit.php?slid=<?php echo $result['productId']; ?>">Edit</a> 
								|| <a onclick="return confirm('Are you sure to delete')" href="?delsl=<?php echo $result['productId']; ?>">Delete</a></td>
					</tr>

					 <?php  }  } ?>	
		
				
				 
			</tbody>
		</table>
       </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
    });
</script>
<?php include 'inc/footer.php';?>