<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>

<?php
$filepath = realpath(dirname(__FILE__));
include_once($filepath."/../classes/Contact.php");
?> 
 
<?php
$con = new Contact();
$fm = new Format();

?>


<?php
  if (!isset($_GET['msgid'])  || $_GET['msgid'] == NULL ) {
     echo "<script>window.location = 'inbox.php';  </script>";
  }else {
    $id = $_GET['msgid'];

  }

 ?>


        <div class="grid_10">
            <div class="box round first grid">
                <h2>VIEW MESSAGE</h2>
<?php 
 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<script>window.location = 'inbox.php';  </script>";
    }

?>



        <div class="block"> 


              
 <?php 
 
        $con    = new Contact(); //Create object for User class 
        $getCust = $con->getMessageForViewPageInTheFields($id); // Create this method in our User.php Class
        if ($getCust) {
           while ($result = $getCust->fetch_assoc()) { 
     ?> 
            
        <form action="" method="post">
            <table class="form">
               
                <tr>
                    <td>
                        <label>First Name</label>
                    </td>
                    <td>
<input type="text" readonly="readonly" value="<?php echo $result['firstname']; ?>" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Last Name</label>
                    </td>
                    <td>
                        <input type="text" readonly="readonly" value="<?php echo $result['lastname']; ?>" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Phone</label>
                    </td>
                    <td>
                        <input type="text" readonly="readonly" value="<?php echo $result['phone']; ?>" class="medium" />
                    </td>
                </tr>
               
               

                 <tr>
                    <td>
                        <label>E-mail</label>
                    </td>
                    <td>
                        <input type="text" readonly="readonly" value="<?php echo $result['email']; ?>" class="medium" />
                    </td>
                </tr>
				
				 <tr>
                    <td>
                        <label>Date</label>
                    </td>
                    <td>
<input type="text" readonly="readonly"  value="<?php echo $fm->formatDate($result['date']);  ?>" class="medium" />
                    
                    </td>
                </tr>
              
				
				 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Description</label>
                    </td>
                    <td>
                        <textarea class="tinymce"  name="body">
                            "<?php echo $result['body']; ?>

                        </textarea>
                    </td>
                </tr>
				<tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Back to Inbox" />
                    </td>
                </tr>
            </table>
          </form>
        <?php   } }  ?>
      </div>
     </div>
   </div>
<script type="text/javascript">
    $(document).ready(function () {
        setupLeftMenu();

        $('.datatable').dataTable();
        setSidebarHeight();
    });
</script>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php';?>