<?php include 'inc1/header2.php'; ?>
 
 <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
 <?php 
  $login =  Session::get("cuslogin");
  if ($login == false) {
  	header("Location:login.php");
  }

  ?>
<div  class="container">
    <div  class="row">
        <div class="col-sm-12 col-md-10 col-md-offset-1">
            <table class="table table-hover">
                <thead>
                   <tr>
								<th style="font-size: 20px;" width="5%">Sl</th>
								<th style="font-size: 20px;" width="30%">Product Name</th>
								<th style="font-size: 20px;" width="10%">Image</th>
								<th style="font-size: 20px;" width="15%">Price</th>
								  
								<th style="font-size: 20px;"width="10%">Action</th>
							</tr>
                </thead>
                 <?php
                     $cmrId =  Session::get("cmrId");
 					$getPd = $pd->getCompareProduct($cmrId);
 					if ($getPd) {
 						$i = 0;
 						 
 						while ($result = $getPd->fetch_assoc()) {
 							 $i++;
 						         ?>
                <tbody>
                    <tr>
                        <td><?php echo $i;  ?></td>
								<td style="font-size: 20px;"><?php echo $result['productName'];  ?></td>
								<td style="font-size: 20px;"><img style="height: 30px;width: 30px;" src="admin/<?php echo $result['image']; ?>" alt=""/></td>
								<td style="font-size: 20px;">$ <?php echo $result['price'];  ?></td>
								<td style="font-size: 20px; color: #29a3a3;"><a href="preview.php?proid=<?php echo $result['productId']; ?>">  View </a> </td>
                    </tr>
                    <?php } }   ?>
                   
                    
                </tbody>
            </table>
        </div>
        <div class="shopping">
						<div class="shopleft">
							<a style="background-color:#29a3a3; " href="index.php"> Continue Shopping</a>
						</div>
						 
					</div>
    </div>
</div>
   
    <?php include 'inc1/footer.php'; ?>