



<?php include"inc1/header.php";  ?>
    <!--NAV NAVBAR ENDS HERE -->
    <style type="text/css">
        #fas {background-color:#29a3a3; }
    </style>
    <!--HOME FIRST SECTION STARTS HERE -->

<header id="home-section">
<div class="dark-overly">
<div class="home-inner container">
<div class="row">

    <div style="color: white;" class="col-lg-8">

        <h1 style="color: white;"class="display-4">You'll <strong>never</strong> know the strength of wibsite 
                  </h1>
                  <br>
<strong>until choosing a strong website</strong> is the only choice you have.
            

        <div style="margin-top: 100px;" class="d-flex">
            <div class="p-4 align-self-start">
                <i class="fas fa-check" ></i>
            </div>
            <div class="p-4 align-self-end">
               Make  <strong>better future</strong> for your job .
            </div>
        </div>
        <div class="d-flex">
            <div class="p-4 align-self-start">
                <i class="fas fa-check"></i>
            </div>
            <div class="p-4 align-self-end">
                 If we want to improve we should be <strong>fail </strong>but not with a website .
            </div>
        </div>
       

    </div>
    







   

</div>
</div>
</div>
<img src="img/22.jpg" height="700px" width="1350px">
</header>
    <!--HOME FIRST SECTION ENDS HERE -->
   
   
    <!--Explore  SECTION STARTS HERE -->
<section id="explore-head-section" class="bg-light text-muted py-5">
        <div class="container">
            <div class="row">
                <div class="col text-center py-5">
                    <h1 style="color: #333333;"class="display-4">Choose the templates</h1>
                    <p class="lead">that Customize the design to fit your personal style and professional needs. </p>
                    <a style="color: #000;" href="tamplate.php" class="btn btn-outline-dark">Start now</a>
                </div>
            </div>
        </div>
    </section>
    
    <!--Explore  SECTION EndS HERE -->



 

 <!--Explore Header STARTS HERE -->
   
  <section  id="explore-head-section">
       
               <div class="swiper-container">
    <div class="swiper-wrapper">
      
      <div class="swiper-slide">
        <div class="imgBx">
          <img style="height:300px;width:100%;" src="img/15.jpg">
        </div>
        <div style="margin-top: 15px;" class="bg">
         <a href="#" class="btn btn-outline-light">Start now</a>
          <span style="color: white;">Fashoin</span>
        </div>

      </div>
    
      <div class="swiper-slide">
        <div class="imgBx">
          <img style="height:300px;width:100%;" src="img/16.jpg">
        </div>
        <div style="margin-top: 15px;" class="bg">
          <a href="#" class="btn btn-outline-light">Start now</a>
          <span style="color: white;">Online Shop</span>
        </div>

      </div>
       <div class="swiper-slide">
        <div class="imgBx">
          <img style="height:300px;width:100%;" src="img/17.jpg">
        </div>
        <div style="margin-top: 15px;"class="bg">
          <a href="#" class="btn btn-outline-light">Start now</a>
           <span style="color: white;">Personal Site</span>
        </div>

      </div>
       <div class="swiper-slide">
        <div class="imgBx">
          <img style="height:300px;width:100%;" src="img/18.jpg">
        </div>
        <div style="margin-top: 15px;"class="bg">
          <a href="#" class="btn btn-outline-light">Start now</a>
           <span style="color: white;">Business</span>
        </div>

      </div>
      
      
      
     
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
  </div>
    

            </div>
        </div>
    
</section>
   
    <!--Explore Header  ENDS HERE -->
    <!--CREAT HEAD STARTS HERE -->
    <section id="create-head-section" style="background-color: #29a3a3;" class="nura">
        <div class="container">
            <div class="row">
                <div class="col text-center py-5">
                    <h1 style="color: white;"class="display-4">Tamplate information</h1>
                    <p style="color: white;" class="lead">Completely Mobile Friendly and Futuristic </p>
                    <a href="#" class="btn btn-outline-light">Start now</a>
                </div>
            </div>
        </div>
    </section>
    <!--CREAT HEAD ENDS HERE -->


    <!--Create  SECTION STARTS HERE -->

    <!--Create  SECTION EndS HERE -->
 


     <!--Share Header STARTS HERE -->

    <!--share Header  ENDS HERE -->
<style type="text/css">
  img {
    max-width: 100%;
}
#team {
    padding: 150px 0;
}
#fun-fact, #team {
    background: #f6f7fe;
}
#team .team-section-text {
    padding-top: 70px;
}
.section-count, .section-title {
    font-family: 'Josefin Sans',sans-serif;
}
.section-count {
    height: 120px;
    overflow: hidden;
    font-weight: 100;
}
.section-count>span {
    color: #e6e9f4;
    display: block;
    font-size: 220px;
    line-height: .7em;
}
.section-title {
    color: #3e6edf;
    font-size: 48px;
    font-weight: 300;
    text-transform: capitalize;
    margin-bottom: 20px;
}
.section-text>p {
    margin-bottom: 15px;
}

#team {
    padding: 150px 0
}

#team .team-section-text {
    padding-top: 70px
}

#team .team-single {
    border: 8px solid #e6e9f4;
    margin: 0 auto;
    padding: 15px;
    width: 320px;
    display: none
}

#team .team-single.active {
    display: block
}

#team .team-list>ul {
    list-style: none;
    margin: 0;
    padding: 0
}

#team .team-list>ul>li {
    position: relative;
    margin: 15px 0
}

#team .team-list>ul>li:first-child {
    margin-top: 0
}

#team .team-list>ul>li:last-child {
    margin-bottom: 0
}

#team .team-list>ul>li.active>a>figure:before {
    position: absolute;
    content: '';
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(131, 158, 226, .7)
}

#team .team-list>ul>li.active::after {
    color:#29a3a3;
    content: "";
    font-family: fontawesome;
    margin-top: -10px;
    position: absolute;
    right: 0;
    top: 50%
}

#team .team-list>ul>li>a>figure {
    border-radius: 50%;
    height: 100px;
    overflow: hidden;
    width: 100px;
    position: relative
}

#team .team-info>h4 {
    color: #29a3a3;
    font-size: 16px;
    margin-bottom: 5px;
    margin-top: 20px;
    text-align: center
}

#team .team-img {
    position: relative
}

#team .team-img>img {
    width: 100%;
    -webkit-transition: .3s;
    -o-transition: .3s;
    transition: .3s
}

#team .team-social>ul {
    bottom: 0;
    list-style: none;
    margin: 0 0 0 20px;
    padding: 0;
    position: absolute;
    right: 30px;
    opacity: 0;
    -webkit-transition: .5s;
    -o-transition: .5s;
    transition: .5s
}

#team .team-social>ul>li>a {
    border-radius: 50%;
    color: #29a3a3;
    display: block;
    font-size: 18px;
    height: 40px;
    margin: 15px 5px;
    padding: 8px;
    position: relative;
    text-align: center;
    width: 40px;
    -webkit-transition: .3s;
    -o-transition: .3s;
    transition: .3s
}
#team .team-social>ul>li>a:hover {
    background: #29a3a3;
    color: #fff
}

#team .team-social>ul>li>a::after {
    border: 1px solid #dee3f4;
    border-radius: 50%;
    content: "";
    height: 50px;
    left: -5px;
    position: absolute;
    top: -5px;
    width: 50px
}

#team .team-single:hover .team-img>img {
    margin-left: -70px
}

#team .team-single:hover .team-social>ul {
    opacity: 1;
    right: 0
}

@media screen and (max-width:1200px) {
    #team {
        padding: 120px 0
    }
}

@media screen and (max-width:991px) {
    #team {
        padding: 90px 0
    }
    #team .col-md-5.col-sm-12.pull-right {
        float: none!important
    }
    #team .team-section-text {
        padding-bottom: 50px;
        padding-top: 0
    }
}

@media screen and (max-width:767px) {
    #team {
        padding: 60px 0
    }
    #team .team-section-text {
        padding-bottom: 30px;
        padding-top: 0
    }
    #team .team-single {
        margin: 30px auto 0;
        overflow: hidden;
        padding: 10px;
        width: 100%
    }
    #team .team-list {
        text-align: center
    }
    #team .team-list>ul>li {
        position: relative
    }
    #team .team-list>ul>li>a>figure {
        height: 65px;
        position: relative;
        width: 65px
    }
    #team .team-list>ul>li.active::after {
        margin-top: 10px;
        position: absolute;
        right: 30px!important;
        top: 100%;
        -webkit-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        transform: rotate(90deg)
    }
    #team .team-list>ul>li {
        display: inline-block;
        margin: 15px 0
    }
}










@media screen and (max-width: 1200px){
  #team {
    padding: 120px 0;
  }
}
@media screen and (max-width: 991px){
  #team {
      padding: 90px 0;
  }
  #team .team-section-text {
    padding-bottom: 50px;
    padding-top: 0;
}
}
</style>
    <!--share-section  SECTION STARTS HERE -->
   <!-- START TEAM -->
    <section id="team">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-sm-12 pull-right">
                    <div class="team-section-text">
                       
                        <!-- END section-count-->
                        <div class="section-text">
                            <h2 style="color: #333333;"class="section-title">Nurin Team</h2>
                            <p>
                                In our Team We have Web Desinger and Web Developer who are :

                            </p>
                        </div>
                        <!-- END section-text-->
                    </div>
                    <!-- END team-section-text-->
                </div>
                <!-- END col-md-5 col-sm-12 pull-right-->
                <div class="col-md-7 col-sm-12">
                    <div class="row">
                        <div class="col-md-3 col-sm-4">
                            <div class="team-list">
                                <ul>
                                    <li class="wow zoomIn" data-wow-duration="1s" data-wow-delay=".1s">
                                        <a href="#team-1" data-team="team-1">
                                            <figure>
                                                <img src="img/24.jpg" alt="Team Member image One">
                                            </figure>
                                        </a>
                                    </li>
                                    <li class="active wow zoomIn" data-wow-duration="1s" data-wow-delay=".3s">
                                        <a href="#team-2" data-team="team-2">
                                            <figure>
                                                <img src="img/21.jpg" alt="Team Member image two">
                                            </figure>
                                        </a>
                                    </li>
                                    <li class="wow zoomIn" data-wow-duration="1s" data-wow-delay=".5s">
                                        <a href="#team-3" data-team="team-3">
                                            <figure>
                                                <img src="img/23.jpg" alt="Team Member image three">
                                            </figure>
                                        </a>
                                    </li>
                                  
                                </ul>
                            </div>
                            <!-- END team-list-->
                        </div>
                        <!-- END col-sm-4-->
                        <div class="col-md-9 col-sm-8">

                            <div id="team-1" class="team-single">
                                <div class="team-img">
                                    <img src="img/24.jpg" alt="">
                                    <div class="team-social">
                                        <ul>
                                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                            <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                    <!-- END team-social-->
                                </div>
                                <!-- END team-img-->
                                <div class="team-info text-center">
                                    <h4>Nur Aga Rajaie</h4>
                                    <p>Founder of Nurin</p>
                                </div>
                                <!-- END team-info-->
                            </div>
                            <!-- END team-single-->


                            <div id="team-2" class="team-single active">
                                <div class="team-img">
                                    <img src="img/21.jpg" alt="">
                                    <div class="team-social">
                                        <ul>
                                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                            <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                    <!-- END team-social-->
                                </div>
                                <!-- END team-img-->
                                <div class="team-info text-center">
                                    <h4>Nur Aga Rajaie</h4>
                                    <p>Web Designer</p>
                                </div>
                                <!-- END team-info-->
                            </div>
                            <!-- END team-single-->


                            <div id="team-3" class="team-single">
                                <div class="team-img">
                                    <img src="img/23.jpg" alt="">
                                    <div class="team-social">
                                        <ul>
                                            <li><a href=""><i class="fa fa-facebook"></i></a></li>
                                            <li><a href=""><i class="fa fa-twitter"></i></a></li>
                                            <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                                        </ul>
                                    </div>
                                    <!-- END team-social-->
                                </div>
                                <!-- END team-img-->
                                <div class="team-info text-center">
                                    <h4>Nur Aga Rajaie</h4>
                                    <p>Web Developer</p>
                                </div>
                                <!-- END team-info-->
                            </div>
                            <!-- END team-single-->


                            
                            <!-- END team-single-->

                        </div>
                        <!-- END col-sm-8-->
                    </div>
                    <!-- END row-->
                </div>
                <!-- END col-md-7 col-sm-12 -->
            </div>
            <!-- END row-->
        </div>
        <!-- END container-->
    </section>
    <!-- END team-->
    <!-- END TEAM -->
    <!--Explore  SECTION EndS HERE -->
 
    <footer id="main-footer" class="bg-dark">
        <div class="container">
            <div class="row">
                <div class="col text-center py-4">
                    <h3 style="color: white;"class="py-3">Nurin</h3>
    
                   <a href="contact.php"  class="btn btn-outline-secondary">Contact to Nurin</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- CONTACT MODAL-->
    <div class="modal fade text-dark" id="contactModal">
     <div class="modal-dialog">
     <div class="modal-content">
     <div class="modal-header">
         <h4 class="modal-title">Contact Us</h4>
         <button class="close" data-dismiss="modal">
             <span>&times;</span>
         </button>
     </div>


     <div class="modal-body">
        <form>
       
      </form>
     </div>
     <div class="modal-footer">
         <button class="btn btn-primary btn-block">Submit</button>
     </div>
    </div>
   </div>
  </div>

    <script src="http://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script>
        
        $('#year').text(new Date().getFullYear());
        //Init Scrooly 
        $('body').scrollspy({target: '#main-nav'});

        // to make it smooth scrooling
        $("#main-nav a").on('click', function(event){
        if(this.hssh !== ""){ 
            event.preventDefault();
            const hash = this.hash;

            $('html, body').animate({
                scrollTop: $(hash).offset().top
                }, 800, function(){
                    window.location.hash = hash;
                });
            }
        });
    </script>
   <script>
    var swiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: 'auto',
      coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows : true,
      },
      pagination: {
        el: '.swiper-pagination',
      },
    });
  </script>
  <script type="text/javascript">$(document).ready(function() {
    "use strict";
  $(".team-list").on("click", "a", function(a) {
        a.preventDefault();
        var e = $(this).data("team");
        $(".team-single").removeClass("active"), $(".team-list li").removeClass("active"), $("#" + e).addClass("active"), $(this).parent().addClass("active")
    });
  
});</script>

</body>

</html>